IF DB_ID(N'EcoCashDB') IS NULL CREATE DATABASE [EcoCashDB];
GO
USE [EcoCashDB];
GO

IF OBJECT_ID(N'dbo.Accounts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Accounts (
        AccountID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        PhoneNumber INT NOT NULL UNIQUE,
        Name NVARCHAR(100) NOT NULL,
        PIN NVARCHAR(4) NOT NULL,
        Balance DECIMAL(10, 2) NOT NULL,
        CreatedDate DATETIME NOT NULL DEFAULT GETDATE()
    );
END;
GO
IF OBJECT_ID(N'dbo.Transactions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Transactions (
        TransactionID INT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        AccountID INT NOT NULL,
        TransactionType NVARCHAR(50) NOT NULL,
        Amount DECIMAL(10, 2) NOT NULL,
        Reference NVARCHAR(50) NOT NULL,
        TransactionDate DATETIME NOT NULL,
        Status NVARCHAR(20) NOT NULL,
        RecipientAccountID INT NULL,
        FOREIGN KEY (AccountID) REFERENCES dbo.Accounts(AccountID),
        FOREIGN KEY (RecipientAccountID) REFERENCES dbo.Accounts(AccountID)
    );
END;
GO
SET IDENTITY_INSERT dbo.Accounts ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Accounts WHERE AccountID = 1) INSERT INTO dbo.Accounts (AccountID, PhoneNumber, Name, PIN, Balance, CreatedDate) VALUES (1, 61234567, N'Thato Motseki', N'1234', 2500.00, CONVERT(DATETIME, '2026-10-21T16:28:37.813', 126));
IF NOT EXISTS (SELECT 1 FROM dbo.Accounts WHERE AccountID = 2) INSERT INTO dbo.Accounts (AccountID, PhoneNumber, Name, PIN, Balance, CreatedDate) VALUES (2, 62345678, N'Mpho Mokoena', N'4321', 3086.84, CONVERT(DATETIME, '2026-10-21T16:28:37.817', 126));
IF NOT EXISTS (SELECT 1 FROM dbo.Accounts WHERE AccountID = 3) INSERT INTO dbo.Accounts (AccountID, PhoneNumber, Name, PIN, Balance, CreatedDate) VALUES (3, 63456789, N'Lerato Phiri', N'1111', 3200.00, CONVERT(DATETIME, '2026-10-21T16:28:37.820', 126));
IF NOT EXISTS (SELECT 1 FROM dbo.Accounts WHERE AccountID = 4) INSERT INTO dbo.Accounts (AccountID, PhoneNumber, Name, PIN, Balance, CreatedDate) VALUES (4, 63290684, N'Kananelo Joel', N'0000', 1928.77, CONVERT(DATETIME, '2026-10-21T16:46:47.860', 126));
SET IDENTITY_INSERT dbo.Accounts OFF;
GO

SET IDENTITY_INSERT dbo.Transactions ON;
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 2) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (2, 4, N'Deposit', 5000.00, N'EC20261021164705', CONVERT(DATETIME, '2026-10-21T16:47:05.563', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 3) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (3, 4, N'Send Money', 1200.00, N'EC20261021164724', CONVERT(DATETIME, '2026-10-21T16:47:24.097', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 4) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (4, 2, N'Send Money', 625.52, N'EC20261021205040', CONVERT(DATETIME, '2026-10-21T20:50:40.573', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 5) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (5, 2, N'Deposit', 5012.36, N'EC20261021205055', CONVERT(DATETIME, '2026-10-21T20:50:55.760', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 6) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (6, 2, N'Cash Out', 6800.00, N'EC20261021205109', CONVERT(DATETIME, '2026-10-21T20:51:09.670', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 7) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (7, 4, N'Deposit', 75.00, N'EC20261021210634', CONVERT(DATETIME, '2026-10-21T21:06:34.963', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 8) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (8, 4, N'Deposit', 500.00, N'EC20261021210711', CONVERT(DATETIME, '2026-10-21T21:07:11.790', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 9) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (9, 4, N'Cash Out', 5000.00, N'EC20261021210724', CONVERT(DATETIME, '2026-10-21T21:07:25.000', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 10) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (10, 4, N'Deposit', 5005.75, N'EC20261021210735', CONVERT(DATETIME, '2026-10-21T21:07:35.980', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 11) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (11, 4, N'Send Money', 2500.00, N'EC20261021210853', CONVERT(DATETIME, '2026-10-21T21:08:53.323', 126), N'Successful', NULL);
IF NOT EXISTS (SELECT 1 FROM dbo.Transactions WHERE TransactionID = 12) INSERT INTO dbo.Transactions (TransactionID, AccountID, TransactionType, Amount, Reference, TransactionDate, Status, RecipientAccountID) VALUES (12, 4, N'Cash Out', 577.50, N'EC20261021210941', CONVERT(DATETIME, '2026-10-21T21:09:41.570', 126), N'Successful', NULL);
SET IDENTITY_INSERT dbo.Transactions OFF;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Accounts_PhoneNumber' AND object_id = OBJECT_ID(N'dbo.Accounts'))
    CREATE NONCLUSTERED INDEX IX_Accounts_PhoneNumber ON dbo.Accounts(PhoneNumber);
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_Transactions_AccountID' AND object_id = OBJECT_ID(N'dbo.Transactions'))
    CREATE NONCLUSTERED INDEX IX_Transactions_AccountID ON dbo.Transactions(AccountID);
GO
